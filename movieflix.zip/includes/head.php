<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MovieFlix</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/a3b5e10b5f.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="<?= BASE_URL . '/assets/css/reset.min.css' ?>">
<link rel="stylesheet" href="<?= BASE_URL . '/assets/css/grid.css' ?>">
<link rel="stylesheet" href="<?= BASE_URL . '/assets/css/style.css' ?>">