<footer>
    <div class="container">
        <div class="row">       
            <div class="col-lg-4 col-xl-4 col-md-12 col-sm-12 col-xs-12 social left">
                <h1 class="find-us">FIND US ON</h1>
                <i class="fa-brands fa-facebook"></i>
                <i class="fa-brands fa-instagram"></i>
                <i class="fa-brands fa-twitter"></i>
                <i class="fa-brands fa-pinterest"></i>
                <i class="fa-brands fa-youtube"></i>
                <i class="fa-brands fa-linkedin"></i>
            </div>
            <div class="col-lg-8 col-xl-8 col-md-12 col-sm-12 col-xs-12 center">
                <p class="term"> All materials and contents (text, graphics, and every attributes) of MovieFlix or MovieFlix.com website are copyrights and trademarks of MovieFlix. No part of this website may be reproduced in any form without our written permission. Misuse of the entire content or any part, multiply, translate, use, or utilize it without written permission from MovieFlix will be subject to criminal and / or civil penalties. admin@mflix-web-01 </p>
                <p class="copyright">&copy; 2023 MovieFlix</p>
            </div>
        </div>
    </div>
</footer>