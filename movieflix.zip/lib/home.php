<?php

require 'config/env.php';
include 'error.php';
