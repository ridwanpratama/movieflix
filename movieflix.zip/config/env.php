<?php
define('BASE_URL', 'http://localhost/kuliah/web_programming/movieflix');